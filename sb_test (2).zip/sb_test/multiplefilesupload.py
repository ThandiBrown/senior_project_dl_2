#----------IGNORE----------
import copy
import shutil
import os
from flask import Flask, flash, request, redirect, render_template
from werkzeug.utils import secure_filename

app=Flask(__name__)

app.secret_key = "secret key"
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

UPLOAD_FOLDER = "static/"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def remove_static_folder():
    if os.path.isdir(UPLOAD_FOLDER):
        shutil.rmtree(UPLOAD_FOLDER)

def new_static_folder():
    if not os.path.isdir(UPLOAD_FOLDER):
        os.mkdir(UPLOAD_FOLDER)

ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg'])

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
#------------IGNORE OVER---------

# Organizes images into handwritten, machine and unknown
# FEEL FREE TO MANIPULATE AND CHANGE THIS AS DESIRED
def organize_files(files):
    
    handwritten = []
    machine = []
    unknown = []
    original_file_list = []
    
    # this loop handles five images at a time
    while len(files) != 0:
        # first two files are handwritten
        if len(files) != 0:
            handwritten.append(files[0].filename)
            original_file_list.append(files.pop(0))
        if len(files) != 0:
            handwritten.append(files[0].filename)
            original_file_list.append(files.pop(0))
        # next two files are machine
        if len(files) != 0:
            machine.append(files[0].filename)
            original_file_list.append(files.pop(0))
        if len(files) != 0:
            machine.append(files[0].filename)
            original_file_list.append(files.pop(0))
        # last file is unknown
        if len(files) != 0:
            unknown.append(files[0].filename)
            original_file_list.append(files.pop(0))

    return handwritten, machine, unknown, original_file_list

# This is the first website called when you go to the 5000 website
@app.route('/')
def upload_form():
    remove_static_folder()
    new_static_folder()
    return render_template('upload.html')

# This is the website called once you press the submit button (displays images)
@app.route('/', methods=['POST'])# SUBMIT BUTTON
def upload_file():
    if request.method == 'POST':
        # displays a message if no files were submitted
        if 'files[]' not in request.files:
            flash('No file part')
            return redirect(request.url)

        # retrieve files from website
        files = request.files.getlist('files[]')
        
        # organize files into cattegories
        handwritten, machine, unknown, original_files = organize_files(files)

        # saves files to server (IT IS SAVED IN THE STATIC FOLDER)
        for file in original_files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        # opens output HTML and passes the lists of filenames      
        return render_template("output.html", handwritten = handwritten, machine = machine, unknown = unknown)


if __name__ == "__main__":
    app.run(host='127.0.0.1',port=5000,debug=True,threaded=True)